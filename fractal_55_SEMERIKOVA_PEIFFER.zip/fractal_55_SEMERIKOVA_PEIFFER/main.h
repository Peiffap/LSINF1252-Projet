#ifndef _MAIN_H
#define _MAIN_H

#define LINE_LENGTH 256

extern int d_position;

#endif
