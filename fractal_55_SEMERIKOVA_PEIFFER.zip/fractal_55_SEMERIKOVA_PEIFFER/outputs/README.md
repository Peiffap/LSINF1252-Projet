This folder is destined to store the output bmp files.
